
fun main() {
    println("Welcome to your banking system.")
    println()
    println("What kind of account would you like to make?")
    println("1. Debit Account")
    println("2. Credit Account")
    println("3. Checking Account")

var accountType = ""
var userChoice = 0

while (accountType == "") {
    println("Please choose an option (1, 2, or 3)")
    userChoice = (1..4).random()

    //userChoice = readln().toInt()

    println("The selected choice is $userChoice.")

    when (userChoice) {
        1 -> accountType = "debit"
        2 -> accountType = "credit"
        3 -> accountType = "checking"
        else -> continue
    }

    println("You have created a $accountType account.")

}

var accountBalance = (0..1000).random()

    println("Your current account balance is $$accountBalance.")

val money = (0..1000).random()

var output = 0


fun withdraw(amount: Int): Int {
    accountBalance -= money
    println("You withdrew $$money. New account balance: $$accountBalance.")
    return amount
}

//output = withdraw(amount)


fun debitWithdraw(amount: Int): Int {

    if (accountBalance == 0) {
        println("Can't withdraw. No funds are in this account.")
        return accountBalance
    }
    else if (amount > accountBalance) {
        println("Not enough money for withdraw. Current balance: $$accountBalance.")
        return 0
    }
    else {
        withdraw(amount)
        return amount
    }
}

    //output = debitWithdraw(money)

fun deposit(amount: Int): Int {
    accountBalance += amount
    println("You deposited $$amount. New account balance: $$accountBalance.")
    return amount
}

    //output = deposit(amount)

fun creditDeposit(amount: Int): Int {
    if (accountBalance == 0) {
        println("Account is paid off! Current balance: $$accountBalance.")
        return accountBalance
    } else if (amount > accountBalance) {
        println("Deposit failed. You tried to pay an amount greater than the credit balance. Current balance: $$accountBalance.")
        return 0
    } else deposit(amount)
    return amount
}

    deposit(money)

fun transfer(mode: String) {

    var transferAmount = Int

    when (mode) {
    "withdraw" -> {
        if (accountType == "debit") {
           transferAmount = debitWithdraw(money)
        } else {
            transferAmount = withdraw(money)
    }
    "deposit" -> {
        if (accountType == "credit")
            transferAmount = creditDeposit(money)
        } else {
            transferAmount = deposit(money)
        }
    else -> return
    }
}



}